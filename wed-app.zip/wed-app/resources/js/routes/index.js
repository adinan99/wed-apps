import { createRouter, createWebHistory } from 'vue-router'

import BorrowsIndex from '../components/borrows/borrowsIndex.vue'
import EquipmentsIndex from '../components/equipments/equipmentsIndex.vue'
import ReturnsIndex from '../components/returns/returnsIndex.vue'
import StudentsIndex from '../components/students/studentsIndex.vue'

const routes = [{
    path: '/borrows',
    name: 'borrows.index',
    component: BorrowsIndex,

    path: '/equipments',
    name: 'equipments.index',
    component: EquipmentsIndex,

    path: '/returns',
    name: 'returns.index',
    component: ReturnsIndex,

    path: '/students',
    name: 'students.index',
    component: StudentsIndex,

}];


export default createRouter({
    history: createWebHistory(),
    routes
});