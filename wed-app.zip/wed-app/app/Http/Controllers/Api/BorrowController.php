<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\borrow;
use Illuminate\Http\Request;
use App\Http\Resources\BorrowResource;

class BorrowController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return BorrowResource::collection(Borrow::all());
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $borrow = Borrow::create($request->validate()); 
        return new BorrowResource ($borrow);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\borrows  $borrows
     * @return \Illuminate\Http\Response
     */
    public function show(borrow $borrow)
    {
        return new BorrowResource ($borrow);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\borrows  $borrows
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, borrow $borrow)
    {
        $borrow = Borrow::create($request->validate()); 
        return new BorrowResource ($borrow);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\borrows  $borrows
     * @return \Illuminate\Http\Response
     */
    public function destroy(borrow $borrow)
    {
        $borrow->delete();
        return response()->noContent();
    }
}
