<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\equipment;
use Illuminate\Http\Request;
use App\Http\Resources\EquipmentResource;

class EquipmentController extends Controller
{
   /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return EquipmentResource::collection(Equipment::all());
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $equipment = Equipment::create($request->validate()); 
        return new EquipmentResource ($equipment);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\borrows  $borrows
     * @return \Illuminate\Http\Response
     */
    public function show(Equipment $equipment)
    {
        return new EquipmentResource ($equipment);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\borrows  $borrows
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Equipment $equipment)
    {
        $borrow = Equipment::create($request->validate()); 
        return new EquipmentResource ($equipment);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\borrows  $borrows
     * @return \Illuminate\Http\Response
     */
    public function destroy(equipment $equipment)
    {
        $equipment->delete();
        return response()->noContent();
    }
}
