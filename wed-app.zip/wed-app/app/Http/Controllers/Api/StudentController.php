<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\student;
use Illuminate\Http\Request;
use App\Http\Resources\StudentResource;


class StudentController extends Controller
{
       /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return StudentResource::collection(Student::all());
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $student = Student::create($request->validate()); 
        return new StudentResource ($student);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\borrows  $borrows
     * @return \Illuminate\Http\Response
     */
    public function show(student $student)
    {
        return new StudentResource ($student);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\borrows  $borrows
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Student $student)
    {
        $borrow = Student::create($request->validate()); 
        return new StudentResource ($student);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\borrows  $borrows
     * @return \Illuminate\Http\Response
     */
    public function destroy(student $student)
    {
        $student->delete();
        return response()->noContent();
    }
}
