<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\returns;
use Illuminate\Http\Request;
use App\Http\Resources\ReturnsResource;

class ReturnsController extends Controller
{
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return ReturnsResource::collection(returns::all());
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $returns = Returns::create($request->validate()); 
        return new ReturnsResource ($returns);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\borrows  $borrows
     * @return \Illuminate\Http\Response
     */
    public function show(returns $returns)
    {
        return new ReturnsResource ($returns);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\borrows  $borrows
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, returns $returns)
    {
        $returns = Returns::create($request->validate()); 
        return new ReturnsResource ($returns);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\borrows  $borrows
     * @return \Illuminate\Http\Response
     */
    public function destroy(returns $returns)
    {
        $returns->delete();
        return response()->noContent();
    }
}
