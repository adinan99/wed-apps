<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class borrow extends Model
{
    use HasFactory;
    protected $fillable = ['b_id', 'b_time', 'b_s_id', 'b_e'];

}
