<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\BorrowController;
use App\Http\Controllers\Api\EquipmentController;
use App\Http\Controllers\Api\ReturnsController;
use App\Http\Controllers\Api\StudentResource;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::apiResource('borrows', BorrowController::class);
Route::apiResource('equipments', EquipmentController::class);
Route::apiResource('returns', ReturnsController::class);
Route::apiResource('students', StudentResource::class);